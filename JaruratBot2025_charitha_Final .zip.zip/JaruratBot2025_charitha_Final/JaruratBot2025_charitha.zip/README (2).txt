Project: JaruratBot - WhatsApp Chatbot  
By: Sowmya Reddy Chagam

Description:
This is a backend chatbot project built using Java and Spring Boot that sends WhatsApp messages using Meta's API.

How to Run:
1. Open project in VS Code
2. Run ChatbotApplication.java
3. Go to: http://localhost:8085/send-message
4. Message will be sent to WhatsApp

Status: Working ✅
